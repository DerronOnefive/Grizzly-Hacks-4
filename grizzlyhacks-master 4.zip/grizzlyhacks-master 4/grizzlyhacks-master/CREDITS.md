# Spring 2023
* **Justin Sandman** :space_invader:
  * Data Modeler (Primary Role)
  * Code Architect (Secondary Role)
* **Szavior McRae** :technologist:
  * Team Manager (Primary Role)
  * Client Liaison (Secondary Role)
* **Riley Housden** :octopus:
  * Documentation Lead (Primary Role)
  * Code Architect (Secondary Role)
* **Jordan Moats** 
  * UI/UX Design Lead (Primary Role)
  * Testing Lead (Secondary Role)
