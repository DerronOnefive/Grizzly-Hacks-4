import { UserQueryPipe } from './user-query.pipe';

describe('UserQueryPipe', () => {
  it('create an instance', () => {
    const pipe = new UserQueryPipe();
    expect(pipe).toBeTruthy();
  });
});
