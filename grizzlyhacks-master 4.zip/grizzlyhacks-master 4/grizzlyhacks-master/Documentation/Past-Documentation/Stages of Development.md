# Stages of Development

- [ ] Basic Layout
- [ ] Registration Function & Admin Page
- [ ] Calendar & Scheduling
  - [ ] Admin should be able to change without updating layout.
- [ ] Everything else
  - [ ] Bribe Art students for layout images
